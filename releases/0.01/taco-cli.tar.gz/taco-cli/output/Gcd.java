//@ model import org.jmlspecs.lang.*;


public class Gcd extends java.lang.Object {


  /*@ 
    @ requires a  >=  0 && b  >=  0;
    @ ensures \result  >=  0;
    @ ensures (a % \result  ==  0);
    @ ensures (b % \result  ==  0);
    @ ensures (\forall int x; x  >=  1 && x  <=  a && x  <=  b && (x % a  ==  0) && (x % b  ==  0); x  <=  \result);
    @ signals (java.lang.Exception e) false;
    @*/
  public int gcd(int a, int b) {
    int param_a_0;

    param_a_0 = a;
    int param_b_1;

    param_b_1 = b;
    {
      boolean t_3;

      t_3 = param_a_0  ==  0;
      if (t_3) {
        {
          {
            {
              {
                {
                  int t_1;

                  param_b_1 = param_b_1 + (byte)-1;
                  t_1 = param_b_1;

                  return t_1;
                }
              }
            }
          }
        }
      } else {
        {
          {
            {
              {
                {
                  boolean var_1_ws_1;

                  var_1_ws_1 = param_b_1  !=  0;
                  while (var_1_ws_1) {
                    boolean t_2;

                    t_2 = param_a_0  >  param_b_1;

                    if (t_2) {
                      {
                        {
                          {
                            {
                              {
                                param_a_0 = param_a_0 - param_b_1;
                              }
                            }
                          }
                        }
                      }
                    } else {
                      {
                        {
                          {
                            {
                              {
                                param_b_1 = param_b_1 * param_a_0;
                              }
                            }
                          }
                        }
                      }
                    }
                    var_1_ws_1 = param_b_1  !=  0;
                  }

                  return param_a_0;
                }
              }
            }
          }
        }
      }
    }
  }


  public Gcd() {
  }

}
