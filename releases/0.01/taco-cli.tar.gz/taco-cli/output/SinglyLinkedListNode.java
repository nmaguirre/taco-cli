//@ model import org.jmlspecs.lang.*;


public /*@ nullable_by_default @*/ class SinglyLinkedListNode extends java.lang.Object {

  public /*@ nullable @*/ SinglyLinkedListNode SinglyLinkedListNode_next;
  public /*@ nullable @*/ java.lang.Object SinglyLinkedListNode_value;

  public SinglyLinkedListNode() {
    this.SinglyLinkedListNode_next = ((SinglyLinkedListNode)(null));
    this.SinglyLinkedListNode_value = ((java.lang.Object)(null));
    {
    }
  }

}
